
import { getProductByHandle } from "@/lib/shopify/products";
import AddToCartButton from "@/components/AddToCartButton";

export default async function ProductPage({ params }: { params: { handle: string } }) {
  const product = await getProductByHandle(params.handle);
  if (!product) return <div>Product not found</div>;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">{product.title}</h1>
      <p>{product.description}</p>
      <AddToCartButton product={product} />
    </div>
  );
}
