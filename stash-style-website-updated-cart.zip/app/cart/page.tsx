
'use client';

import { useEffect, useState } from 'react';
import { getOrCreateCart, getCart, updateCartLine, removeCartLine } from '@/lib/shopify/cart';

export default function CartPage() {
  const [cart, setCart] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadCart() {
      const cartId = await getOrCreateCart();
      const data = await getCart(cartId);
      setCart(data.cart);
      setLoading(false);
    }
    loadCart();
  }, []);

  async function handleUpdate(lineId: string, quantity: number) {
    if (!cart) return;
    const updated = await updateCartLine(cart.id, lineId, quantity);
    setCart(updated.cart);
  }

  async function handleRemove(lineId: string) {
    if (!cart) return;
    const updated = await removeCartLine(cart.id, lineId);
    setCart(updated.cart);
  }

  if (loading) return <div className="p-6">Loading cart...</div>;
  if (!cart || cart.lines.edges.length === 0) return <div className="p-6">Your cart is empty.</div>;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Your Cart</h1>
      <ul className="space-y-4">
        {cart.lines.edges.map(({ node }: any) => (
          <li key={node.id} className="flex items-center justify-between border-b pb-2">
            <div>
              <p className="font-semibold">{node.merchandise.product.title}</p>
              <p className="text-sm text-gray-500">Qty: {node.quantity}</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => handleUpdate(node.id, node.quantity + 1)}
                className="px-2 py-1 border rounded"
              >
                +
              </button>
              <button
                onClick={() => handleUpdate(node.id, Math.max(1, node.quantity - 1))}
                className="px-2 py-1 border rounded"
              >
                -
              </button>
              <button
                onClick={() => handleRemove(node.id)}
                className="px-2 py-1 border rounded text-red-500"
              >
                Remove
              </button>
            </div>
          </li>
        ))}
      </ul>
      <div className="mt-6">
        <p className="font-semibold">Subtotal: {cart.cost.subtotalAmount.amount} {cart.cost.subtotalAmount.currencyCode}</p>
        <a
          href={cart.checkoutUrl}
          className="inline-block mt-4 bg-black text-white px-4 py-2 rounded"
        >
          Checkout
        </a>
      </div>
    </div>
  );
}
