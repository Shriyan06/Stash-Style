
'use client';

const endpoint = '/api/shopify/cart';

export async function getOrCreateCart() {
  let cartId = localStorage.getItem('cartId');
  if (!cartId) {
    const res = await fetch(endpoint + '/create', { method: 'POST' });
    const data = await res.json();
    cartId = data.cart.id;
    localStorage.setItem('cartId', cartId);
  }
  return cartId;
}

export async function addToCart(variantId: string, quantity: number = 1) {
  const cartId = await getOrCreateCart();
  const res = await fetch(endpoint + '/add', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cartId, variantId, quantity }),
  });
  return res.json();
}

export async function getCart(cartId: string) {
  const res = await fetch(endpoint + `/${cartId}`);
  return res.json();
}

export async function updateCartLine(cartId: string, lineId: string, quantity: number) {
  const res = await fetch(endpoint + '/update', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cartId, lineId, quantity }),
  });
  return res.json();
}

export async function removeCartLine(cartId: string, lineId: string) {
  const res = await fetch(endpoint + '/remove', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cartId, lineId }),
  });
  return res.json();
}
